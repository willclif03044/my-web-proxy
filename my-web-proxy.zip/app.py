import os, secrets, socket, ipaddress
from urllib.parse import urlsplit
from flask import Flask, request, Response, render_template_string
import requests
from bs4 import BeautifulSoup
app = Flask(__name__)
PAGE = '''<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Proxy</title><style>body{font:18px system-ui;background:#101827;color:white;max-width:600px;margin:15vh auto;padding:24px}input,button{box-sizing:border-box;padding:15px;border-radius:9px;border:0;font:inherit}input{width:100%;margin:15px 0}button{background:#2563eb;color:white;width:100%}small{color:#aab7ca}</style><h1>My Proxy</h1><p>Enter a website address to retrieve its readable text.</p><form action="/view" method="post"><input name="url" type="url" placeholder="https://example.com" required><button>Go</button></form><p><small>Private, read-only web viewer.</small></p>'''
@app.before_request
def auth():
    password=os.environ.get('PROXY_PASSWORD','')
    a=request.authorization
    if not password or not a or not secrets.compare_digest(a.password or '',password):
        return Response('Authentication required',401,{'WWW-Authenticate':'Basic realm="Private viewer"'})
@app.get('/')
def home(): return PAGE
@app.post('/view')
def view():
    url=request.form.get('url','')
    try:
        p=urlsplit(url)
        # Restrict destinations to an explicit operator-controlled allowlist.
        allowed={x.strip().lower() for x in os.environ.get('ALLOWED_HOSTS','example.com').split(',')}
        if p.scheme!='https' or p.hostname not in allowed or p.username or p.password or p.port not in (None,443): raise ValueError()
        for addr in socket.getaddrinfo(p.hostname,443,type=socket.SOCK_STREAM):
            if not ipaddress.ip_address(addr[4][0]).is_global: raise ValueError()
        with requests.Session() as s:
            s.trust_env=False
            with s.get(url,timeout=(5,10),allow_redirects=False,stream=True) as r:
                if r.status_code!=200 or 'text/html' not in r.headers.get('Content-Type',''): raise ValueError()
                data=bytearray()
                for chunk in r.iter_content(8192):
                    data.extend(chunk)
                    if len(data)>1000000: raise ValueError()
        soup=BeautifulSoup(data,'html.parser')
        for tag in soup(['script','style','iframe','noscript']): tag.decompose()
        return render_template_string('<meta name="viewport" content="width=device-width"><a href="/">Back</a><h1>{{url}}</h1><div style="white-space:pre-wrap;font:16px system-ui">{{body}}</div>',url=url,body=soup.get_text('\n',strip=True))
    except (ValueError, OSError, requests.RequestException): return 'Unable to retrieve this page. Check the allowed hosts and URL. <a href="/">Back</a>',400

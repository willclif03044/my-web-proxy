# Private web viewer
This is a password-protected, read-only text retrieval proxy, not a full browsing proxy. It does not forward cookies, scripts, forms, images or redirects. Only explicitly allowed HTTPS hosts are supported. Use trusted hosts you are authorized to access; DNS checks are not a complete defense against malicious DNS changes.

1. Check that your hosting provider permits this use and offers a free web service.
2. Create a private GitHub repository and upload app.py and requirements.txt (and optionally this README).
3. In Render, create a Web Service connected to that repository. Select Python, and Free if available.
4. Build command: pip install -r requirements.txt
5. Start command: gunicorn --bind 0.0.0.0:$PORT app:app
6. Add environment variables PROXY_PASSWORD (a long unique password) and ALLOWED_HOSTS (comma-separated trusted hostnames, e.g. example.com). Never commit your password.
7. Deploy and open the HTTPS service URL. Enter any username and your configured password. Try https://example.com if allowed.

Free hosting availability and policy have not been verified. This project has not been deployed. Do not use it to bypass network policies or access restrictions.
